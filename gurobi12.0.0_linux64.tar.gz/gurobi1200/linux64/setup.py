#!/usr/bin/python

raise Exception(
	"The setup.py installation method has been removed, gurobipy should "
	"be installed using pip or conda. Please see "
	"https://support.gurobi.com/hc/en-us/articles/360044290292 "
	"for further information."
)
